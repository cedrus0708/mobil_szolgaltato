#ifndef _TESZT
#define _TESZT

#include <iostream>
//#include <sstream>

#include "memtrace.h"
#include "gtest_lite.h"

/// A teszteket futtat� f�ggv�ny
void run_tests();

#endif //_TESZT
